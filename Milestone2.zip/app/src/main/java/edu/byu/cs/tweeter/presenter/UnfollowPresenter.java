package edu.byu.cs.tweeter.presenter;

import java.io.IOException;

import edu.byu.cs.tweeter.model.service.FollowService;
import edu.byu.cs.tweeter.model.service.UnfollowService;
import edu.byu.cs.tweeter.model.service.request.FollowRequest;
import edu.byu.cs.tweeter.model.service.request.UnfollowRequest;
import edu.byu.cs.tweeter.model.service.response.FollowResponse;
import edu.byu.cs.tweeter.model.service.response.UnfollowResponse;

/**
 * The presenter for the login functionality of the application.
 */
public class UnfollowPresenter {

    private final View view;

    /**
     * The interface by which this presenter communicates with it's view.
     */
    public interface View {
        // If needed, specify methods here that will be called on the view in response to model updates
    }

    /**
     * Creates an instance.
     *
     * @param view the view for which this class is the presenter.
     */
    public UnfollowPresenter(View view) {
        this.view = view;
    }

    /**
     * Makes a login request.
     *
     * @param unfollowRequest the request.
     */
    public UnfollowResponse unfollow(UnfollowRequest unfollowRequest) throws IOException {
        UnfollowService unfollowService = new UnfollowService();
        return unfollowService.unfollow(unfollowRequest);
    }
}
